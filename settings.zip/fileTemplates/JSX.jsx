import React from 'react';
import PropTypes from 'prop-types';
import Button from '@material-ui/core/Button';

const component = ({}) => (
    <Button />
);

component.propTypes = {
  
};

export default component;